package com.sist.vo;

public class ProductVO {
private int pdno,goods_count;
private String title,poster,subject,sale,priced_sale,original_pri,first_pri,delivery_pri;
double score;
public int getPdno() {
	return pdno;
}
public void setPdno(int pdno) {
	this.pdno = pdno;
}
public int getGoods_count() {
	return goods_count;
}
public void setGoods_count(int goods_count) {
	this.goods_count = goods_count;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getPoster() {
	return poster;
}
public void setPoster(String poster) {
	this.poster = poster;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public String getSale() {
	return sale;
}
public void setSale(String sale) {
	this.sale = sale;
}
public String getPriced_sale() {
	return priced_sale;
}
public void setPriced_sale(String priced_sale) {
	this.priced_sale = priced_sale;
}
public String getOriginal_pri() {
	return original_pri;
}
public void setOriginal_pri(String original_pri) {
	this.original_pri = original_pri;
}
public String getFirst_pri() {
	return first_pri;
}
public void setFirst_pri(String first_pri) {
	this.first_pri = first_pri;
}
public String getDelivery_pri() {
	return delivery_pri;
}
public void setDelivery_pri(String delivery_pri) {
	this.delivery_pri = delivery_pri;
}
public double getScore() {
	return score;
}
public void setScore(double score) {
	this.score = score;
}

}
