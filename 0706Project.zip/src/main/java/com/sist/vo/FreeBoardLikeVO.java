package com.sist.vo;
/*
	NO NUMBER,
	id VARCHAR2(20),
	bno NUMBER
 */
public class FreeBoardLikeVO {
	private int no,bno;
	private String id;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
}
